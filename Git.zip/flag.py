
print("Hello, Hacker💻")
